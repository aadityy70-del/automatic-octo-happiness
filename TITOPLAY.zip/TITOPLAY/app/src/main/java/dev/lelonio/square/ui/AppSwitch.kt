package dev.lelonio.square.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import dev.lelonio.square.R
import dev.lelonio.square.SquareApplication
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * The way over to the sibling app (AETHER), and back.
 *
 * Holding the home icon for five seconds turns the logo over a black screen
 * and opens the other app. The YouTube Music sign-in goes with it, straight to
 * that one app and nowhere else, so a listener signed in here is signed in
 * there; the other app does the same on the way back. A sign-in is only ever
 * taken by an app that is signed out, never over an account that is in use.
 */
object AppSwitch {
    /** The sibling's package: the release build, the debug build, a side-by-side one. */
    private val SIBLINGS = listOf("app.aether", "app.aether.debug", "app.aether.rc")

    const val EXTRA_COOKIE = "titoplay.cookie"

    /** True while the logo is turning, until the other app is up. */
    val spinning = mutableStateOf(false)

    fun launchIntent(context: Context): Intent? =
        SIBLINGS.firstNotNullOfOrNull { context.packageManager.getLaunchIntentForPackage(it) }

    fun begin(context: Context, view: View?): Boolean {
        if (spinning.value) return false
        if (launchIntent(context) == null) {
            Toast.makeText(context, "AETHER is not installed", Toast.LENGTH_SHORT).show()
            return false
        }
        view?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        spinning.value = true
        return true
    }

    /** Opens the sibling with this app's sign-in, if there is one, in its intent. */
    fun go(context: Context) {
        val intent = launchIntent(context)
        if (intent != null) {
            val cookie = (context.applicationContext as SquareApplication)
                .youtubeAccount.cookieForHandoff()
            if (cookie != null) intent.putExtra(EXTRA_COOKIE, cookie)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching {
                context.startActivity(intent)
                (context as? Activity)?.overridePendingTransition(
                    android.R.anim.fade_in, android.R.anim.fade_out,
                )
            }
        }
        spinning.value = false
    }

    /** Takes a sign-in the sibling handed over, when this app has none. */
    fun receive(activity: ComponentActivity, intent: Intent?) {
        val cookie = intent?.getStringExtra(EXTRA_COOKIE) ?: return
        intent.removeExtra(EXTRA_COOKIE)
        val account = (activity.application as SquareApplication).youtubeAccount
        if (account.adopt(cookie)) {
            activity.lifecycleScope.launch { runCatching { account.revalidate() } }
        }
    }
}

/** Held for [ms] without letting go; the touch itself is left alone, so a tap still taps. */
fun Modifier.holdToSwitch(ms: Long = 5_000L): Modifier = composed {
    val context = LocalContext.current
    val view = LocalView.current
    pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var lifted = false
            val stillDown = withTimeoutOrNull(ms) {
                while (!lifted) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    if (event.changes.none { it.pressed }) lifted = true
                }
                true
            }
            if (stillDown == null) AppSwitch.begin(context, view)
        }
    }
}

/** The logo turning over black, then the other app. */
@Composable
fun AppSwitchOverlay() {
    if (!AppSwitch.spinning.value) return
    val context = LocalContext.current
    val turn = remember { Animatable(0f) }
    val dark = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { dark.animateTo(1f, tween(450)) }
        turn.animateTo(1f, tween(1300, easing = FastOutSlowInEasing))
        delay(80)
        AppSwitch.go(context)
    }
    Box(
        Modifier
            .fillMaxSize()
            .alpha(dark.value)
            .background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.splash_logo),
            contentDescription = null,
            modifier = Modifier
                .size(178.dp)
                .graphicsLayer {
                    rotationZ = turn.value * 720f
                    val s = 1f - 0.25f * kotlin.math.sin(turn.value * Math.PI).toFloat()
                    scaleX = s
                    scaleY = s
                },
        )
    }
}
